﻿using UnityEngine;
using System.Collections.Generic;

namespace Rewired.Integration.BehaviorDesigner {

    using global::BehaviorDesigner.Runtime;
    using global::BehaviorDesigner.Runtime.Tasks;

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Enabled")]
    [TaskDescription("Gets whether the controller is enabled. Disabled controllers return no input.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetEnabled : ControllerGetBoolAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Controller.enabled);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Set Controller Enabled")]
    [TaskDescription("Sets whether the controller is enabled. Disabled controllers return no input.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerSetEnabled : ControllerSetBoolAction {

        protected override TaskStatus DoUpdate() {
            Controller.enabled = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Id")]
    [TaskDescription("Gets the Rewired unique id of this controller. This is not an index. The id is unique among controllers of a specific controller type.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetId : ControllerGetIntAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Controller.id);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Name")]
    [TaskDescription("Gets the name of the Controller. For Joysticks, this is drawn from the controller definition for recognized Joysticks. For unrecognized Joysticks, the name returned by the hardware is used instead.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetName : ControllerGetStringAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Controller.name);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Tag")]
    [TaskDescription("Gets the tag assigned to the controller. Can be used for find a controller by tag.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetTag : ControllerGetStringAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Controller.tag);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Set Controller Tag")]
    [TaskDescription("Sets the tag assigned to the controller. Can be used for find a controller by tag.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerSetTag : ControllerAction {

        [Tooltip("The tag to set.")]
        public SharedString tag;

        public override void OnReset() {
            base.OnReset();
            tag = string.Empty;
        }

        protected override TaskStatus DoUpdate() {
            Controller.tag = tag.Value;
            return TaskStatus.Success;
        }
    }
    
    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Hardware Name")]
    [TaskDescription("Gets the name the controller hardware returns.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetHardwareName : ControllerGetStringAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Controller.hardwareName);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Type")]
    [TaskDescription("Gets the type of this controller.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetType : ControllerGetIntAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue((int)Controller.type);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Is Controller Connected")]
    [TaskDescription("Is the controller connected?")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetIsConnected : ControllerGetBoolAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Controller.isConnected);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Button Count")]
    [TaskDescription("Gets the button count in the controller.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetButtonCount : ControllerGetIntAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Controller.buttonCount);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Hardware Identifier")]
    [TaskDescription("Gets the string of information from the controller used for identifying unknown controller maps for saving/loading.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetHardwareIdentifier : ControllerGetStringAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Controller.hardwareIdentifier);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Map Type String")]
    [TaskDescription("Gets the string representation of the controller map type. Can be used for saving/loading.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetMapTypeString : ControllerGetStringAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Controller.mapTypeString);
            return TaskStatus.Success;
        }
    }

    // ControllerWithAxes

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Axis Count")]
    [TaskDescription("Gets the axis count in the controller.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetAxisCount : ControllerGetIntAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue((Controller as ControllerWithAxes).axis2DCount);
            return TaskStatus.Success;
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;
            if(Controller as ControllerWithAxes == null) {
                Debug.LogError("Controller is an incompatible type.");
                return false;
            }
            return true;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Controller Axis2D Count")]
    [TaskDescription("Gets the Axis2D count in the controller.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerGetAxis2DCount : ControllerGetIntAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue((Controller as ControllerWithAxes).axis2DCount);
            return TaskStatus.Success;
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;
            if(Controller as ControllerWithAxes == null) {
                Debug.LogError("Controller is an incompatible type.");
                return false;
            }
            return true;
        }
    }

    // Joystick

    // systemId is not supported because ?long is not a supported type in PlayMaker

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Joystick Unity Id")]
    [TaskDescription("Gets the unity joystick id of this joystick. This value is only used on platforms that use Unity input as the underlying input source. This value is a 1-based index corresponding to the joystick number in the Unity input manager. Generally, you should never need to use this, but it is exposed for advanced uses. Returns 0 if the platform does not use Unity input or if the joystick is not associated with a Unity joystick.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredJoystickGetUnityId : JoystickGetIntAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Joystick.unityId);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Joystick Hardware Type Guid String")]
    [TaskDescription("Gets the Rewired GUID associated with this device. A GUID of all zeros is an Unknown Controller.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredJoystickGetHardwareTypeGuidString : JoystickGetStringAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Joystick.hardwareTypeGuid.ToString());
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Joystick Supports Vibration")]
    [TaskDescription("Does this controller support vibration?")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredJoystickGetSupportsVibration : JoystickGetBoolAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Joystick.supportsVibration);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_base + "/Controller/Properties")]
    [TaskName("Get Joystick Vibration Motor Count")]
    [TaskDescription("Gets the number of vibration motors this device supports.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredJoystickGetVibrationMotorCount : JoystickGetIntAction {

        protected override TaskStatus DoUpdate() {
            UpdateStoreValue(Joystick.vibrationMotorCount);
            return TaskStatus.Success;
        }
    }
}