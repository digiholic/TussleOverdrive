﻿// Copyright (c) 2016 Augie R. Maddox, Guavaman Enterprises. All rights reserved.
#pragma warning disable 0219
#pragma warning disable 0618
#pragma warning disable 0649

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace Rewired.Integration.UFS.Editor {

    [System.ComponentModel.Browsable(false)]
    [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
    public sealed class RewiredUFSIntegration {
        
        private const uint version = 1;
        private const string rewiredUFSInputManagerPrefabGUID = "49cfb143c3ffe8048b16068034344d5f"; // GUID of the prefab file

        [MenuItem(Consts.menuRoot + "/Integration/uFS/About")]
        public static void Integration_UFS_About() {
            EditorUtility.DisplayDialog("Rewired uFS Integration Pack", "Version: " + version.ToString(), "Close");
        }

        [MenuItem(Consts.menuRoot + "/Integration/uFS/Create Rewired uFS Input Manager")]
        public static void Integration_UFS_CreateInputManager() {

            string pathToPrefab = AssetDatabase.GUIDToAssetPath(rewiredUFSInputManagerPrefabGUID);
            if(pathToPrefab == null || pathToPrefab == string.Empty) {
                Debug.LogWarning("Rewired uFS Input Manager prefab not found at expected Guid! Please reinstall the uFS Integration Pack.");
                return;
            }

            GameObject prefab = (GameObject)AssetDatabase.LoadAssetAtPath(pathToPrefab, typeof(GameObject));
            if(prefab == null) {
                Debug.LogWarning("Rewired uFS Input Manager prefab not found! Please reinstall the uFS Integration Pack.");
                return;
            }
            
            InputManager im = prefab.GetComponent<Rewired.InputManager>();
            if(im == null) {
                Debug.LogWarning("Rewired Input Manager component not found on prefab! Please reinstall the uFS Integration Pack.");
                return;
            }

            // Instantiate the prefab with the default uFS settings
            GameObject go = (GameObject)UnityEngine.Object.Instantiate(prefab, Vector3.zero, Quaternion.identity);
            go.name = prefab.name; // rename the prefab
        }
    }
}