﻿using UnityEngine;
using System.Collections.Generic;

namespace Rewired.Integration.PlayMaker {

    using HutongGames.PlayMaker;
    using HutongGames.PlayMaker.Actions;
    using HutongGames.Extensions;
    using HutongGames.Utility;
    using System;

    #region Players

    [ActionCategory("Rewired")]
    [Tooltip("Count of Players excluding system player.")]
    public class RewiredGetPlayerCount : GetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(ReInput.players.playerCount);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Count of all players including system player.")]
    public class RewiredGetAllPlayersCount : GetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(ReInput.players.allPlayerCount);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets a collection of Player ids. Does not include the System Player.")]
    public class RewiredGetPlayerIds : GetIntArrayFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            IList<Player> players = ReInput.players.Players;
            int count = players != null ? players.Count : 0;

            for(int i = 0; i < count; i++) {
                workingList.Add(players[i].id);
            }

            UpdateStoreValue();
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets a collection of Player ids including the System Player.")]
    public class RewiredGetAllPlayerIds : GetIntArrayFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            IList<Player> players = ReInput.players.AllPlayers;
            int count = players != null ? players.Count : 0;

            for(int i = 0; i < count; i++) {
                workingList.Add(players[i].id);
            }

            UpdateStoreValue();
        }
    }

    #endregion

    #region Controllers

    [ActionCategory("Rewired")]
    [Tooltip("The number of joysticks currently connected.")]
    public class RewiredGetJoystickCount : GetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(ReInput.controllers.joystickCount);
        }
    }

    // REMOVED AT THIS TIME BECAUSE OF POTENTIAL MEMORY BLOAT ISSUES
    // Wait until PlayMaker adds support for storing non-serialized objects.
    /*[ActionCategory("Rewired")]
    [Tooltip("Gets a collection of connected Joysticks.")]
    public class RewiredGetJoysticks : GetSystemObjectArrayFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            IList<Joystick> joysticks = ReInput.controllers.Joysticks;
            int count = joysticks != null ? joysticks.Count : 0;

            for(int i = 0; i < count; i++) {
                workingList.Add(joysticks[i]);
            }

            UpdateStoreValue();
        }
    }*/

    [ActionCategory("Rewired")]
    [Tooltip("Gets a collection of connected Joystick ids.")]
    public class RewiredGetJoystickIds : GetIntArrayFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            IList<Joystick> joysticks = ReInput.controllers.Joysticks;
            int count = joysticks != null ? joysticks.Count : 0;

            for(int i = 0; i < count; i++) {
                workingList.Add(joysticks[i].id);
            }

            UpdateStoreValue();
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets a collection of Custom Controller ids.")]
    public class RewiredGetCustomControllerIds : GetIntArrayFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            IList<CustomController> customControllers = ReInput.controllers.CustomControllers;
            int count = customControllers != null ? customControllers.Count : 0;

            for(int i = 0; i < count; i++) {
                workingList.Add(customControllers[i].id);
            }

            UpdateStoreValue();
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("The number of custom controllers.")]
    public class RewiredGetCustomControllerCount : GetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }
        
        protected override void DoUpdate() {
            UpdateStoreValue(ReInput.controllers.customControllerCount);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Get the last controller type that produced input.")]
    public class RewiredGetLastActiveControllerType : BaseFsmStateAction {

        [RequiredField, UIHint(UIHint.Variable), ObjectType(typeof(ControllerType))]
        [Tooltip("Store the result in an enum variable.")]
        public FsmEnum storeValue;

        [Tooltip("Event to send when the value changes.")]
        public FsmEvent valueChangedEvent;

        public override void Reset() {
            base.Reset();
            storeValue = null;
        }

        protected override void DoUpdate() {
            UpdateStoreValue(ReInput.controllers.GetLastActiveControllerType());
        }

        protected void UpdateStoreValue(Enum newValue) {
            if(!newValue.Equals(storeValue.Value)) { // value changed
                // Store new value
                storeValue.Value = newValue;
                TrySendEvent(valueChangedEvent); // send value changed event
            }
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Is the specified controller assigned to any players?")]
    public class RewiredIsControllerAssigned : GetBoolFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        [RequiredField, ObjectType(typeof(ControllerType))]
        [Tooltip("The type of the controller.")]
        public FsmEnum controllerType;

        [RequiredField, UIHint(UIHint.Variable)]
        [Tooltip("Controller Id of the controller. This currently only applies to Joystick and Custom controller types.")]
        public FsmInt controllerId = 0;

        public override void Reset() {
            base.Reset();
            controllerType = null;
            controllerId = 0;
        }

        protected override void DoUpdate() {
            UpdateStoreValue(ReInput.controllers.IsControllerAssigned((ControllerType)controllerType.Value, controllerId.Value));
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;

            if(ReInput.controllers.GetController((ControllerType)controllerType.Value, controllerId.Value) == null) {
                return false;
            }

            return true;
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Is the specified controller assigned to the specified player?")]
    public class RewiredIsControllerAssignedToPlayer : GetBoolFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        [RequiredField]
        [Tooltip("The Rewired Player Id. To use the System Player, enter any value < 0 or 9999999.")]
        public FsmInt playerId;

        [RequiredField, ObjectType(typeof(ControllerType))]
        [Tooltip("The type of the controller.")]
        public FsmEnum controllerType;

        [RequiredField, UIHint(UIHint.Variable)]
        [Tooltip("Controller Id of the controller. This currently only applies to Joystick and Custom controller types.")]
        public FsmInt controllerId = 0;

        public override void Reset() {
            base.Reset();
            playerId = 0;
            controllerType = null;
            controllerId = 0;
        }

        protected override void DoUpdate() {
            UpdateStoreValue(ReInput.controllers.IsControllerAssignedToPlayer((ControllerType)controllerType.Value, controllerId.Value, playerId.Value));
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;

            if(playerId.IsNone) {
                LogError("Rewired Player Id must be assigned!");
                return false;
            }
            if(playerId.Value != Rewired.Consts.systemPlayerId && (playerId.Value < 0 || playerId.Value >= ReInput.players.playerCount)) {
                LogError("Rewired Player Id is out of range!");
                return false;
            }

            if(ReInput.controllers.GetController((ControllerType)controllerType.Value, controllerId.Value) == null) {
                return false;
            }

            return true;
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("De-assigns the specified controller from all players.")]
    public class RewiredRemoveControllerFromAllPlayers : BaseFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        [RequiredField, ObjectType(typeof(ControllerType))]
        [Tooltip("The type of the controller.")]
        public FsmEnum controllerType;

        [RequiredField, UIHint(UIHint.Variable)]
        [Tooltip("Controller Id of the controller. This currently only applies to Joystick and Custom controller types.")]
        public FsmInt controllerId = 0;

        [Tooltip("Do we de-assign from the System player also?")]
        public FsmBool includeSystemPlayer = true;

        public override void Reset() {
            base.Reset();
            controllerType = null;
            controllerId = 0;
            includeSystemPlayer = true;
        }

        protected override void DoUpdate() {
            ReInput.controllers.RemoveControllerFromAllPlayers((ControllerType)controllerType.Value, controllerId.Value, includeSystemPlayer.Value);
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;

            if(ReInput.controllers.GetController((ControllerType)controllerType.Value, controllerId.Value) == null) {
                return false;
            }

            return true;
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Auto-assigns a Joystick to a Player based on the joystick auto-assignment settings in the Rewired Input Manager. If the Joystick is already assigned to a Player, the Joystick will not be re-assigned.")]
    public class RewiredAutoAssignJoystick : RewiredJoystickFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            ReInput.controllers.AutoAssignJoystick(Joystick);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Auto-assigns all unassigned Joysticks to Players based on the joystick auto-assignment settings in the Rewired Input Manager.")]
    public class RewiredAutoAssignJoysticks : BaseFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            ReInput.controllers.AutoAssignJoysticks();
        }
    }

    #endregion

    #region Time

    [ActionCategory("Rewired")]
    [Tooltip("Current unscaled time since start of the game. Always use this when doing current time comparisons for button and axis active/inactive times instead of Time.time or Time.unscaledTime.")]
    public class RewiredGetUnscaledTime : GetFloatFsmStateAction {

        protected override void DoUpdate() {
            UpdateStoreValue(ReInput.time.unscaledTime);
        }
    }

    #endregion

    #region Events

    [ActionCategory("Rewired")]
    [Tooltip("Event triggered when a controller is conected.")]
    public class RewiredControllerConnectedEvent : BaseFsmStateAction {
        
        [UIHint(UIHint.Variable)]
        [Tooltip("Store the result in a string variable.")]
        public FsmString storeControllerName;

        [UIHint(UIHint.Variable)]
        [Tooltip("Store the result in an int variable.")]
        public FsmInt storeControllerId = -1;

        [ObjectType(typeof(ControllerType))]
        [UIHint(UIHint.Variable)]
        [Tooltip("Store the result in an enum variable.")]
        public FsmEnum storeControllerType;

        [Tooltip("Send event when a controller is connected.")]
        public FsmEvent sendEvent;

        private bool hasEvent = false;

        public override void Awake() {
            base.Awake();
            ReInput.ControllerConnectedEvent += OnControllerConnected;
        }

        public override void Reset() {
            base.Reset();
            storeControllerName = string.Empty;
            storeControllerId = -1;
            storeControllerType = null;
            hasEvent = false;
        }

        protected override void DoUpdate() {
            if(hasEvent) {
                if(!FsmEvent.IsNullOrEmpty(sendEvent)) Fsm.Event(sendEvent);
                hasEvent = false;
            }
        }

        private void OnControllerConnected(ControllerStatusChangedEventArgs args) {
            hasEvent = true;
            storeControllerName.Value = args.name;
            storeControllerId.Value = args.controllerId;
            storeControllerType.Value = args.controllerType;
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Event triggered just before a controller is disconnected. You can use this event to save controller maps before the controller is removed.")]
    public class RewiredControllerPreDisconnectEvent : BaseFsmStateAction {

        [UIHint(UIHint.Variable)]
        [Tooltip("Store the result in a string variable.")]
        public FsmString storeControllerName;

        [UIHint(UIHint.Variable)]
        [Tooltip("Store the result in an int variable.")]
        public FsmInt storeControllerId = -1;

        [ObjectType(typeof(ControllerType))]
        [UIHint(UIHint.Variable)]
        [Tooltip("Store the result in an enum variable.")]
        public FsmEnum storeControllerType;

        [Tooltip("Send event just before a controller is disconnected.")]
        public FsmEvent sendEvent;

        private bool hasEvent = false;

        public override void Awake() {
            base.Awake();
            ReInput.ControllerPreDisconnectEvent += OnControllerPreDisconnect;
        }

        public override void Reset() {
            base.Reset();
            storeControllerName = string.Empty;
            storeControllerId = -1;
            storeControllerType = null;
            hasEvent = false;
        }

        protected override void DoUpdate() {
            if(hasEvent) {
                if(!FsmEvent.IsNullOrEmpty(sendEvent)) Fsm.Event(sendEvent);
                hasEvent = false;
            }
        }

        private void OnControllerPreDisconnect(ControllerStatusChangedEventArgs args) {
            hasEvent = true;
            storeControllerName.Value = args.name;
            storeControllerId.Value = args.controllerId;
            storeControllerType.Value = args.controllerType;
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Event triggered after a controller is disconnected.")]
    public class RewiredControllerDisconnectedEvent : BaseFsmStateAction {

        [UIHint(UIHint.Variable)]
        [Tooltip("Store the result in a string variable.")]
        public FsmString storeControllerName;

        [UIHint(UIHint.Variable)]
        [Tooltip("Store the result in an int variable.")]
        public FsmInt storeControllerId = -1;

        [ObjectType(typeof(ControllerType))]
        [UIHint(UIHint.Variable)]
        [Tooltip("Store the result in an enum variable.")]
        public FsmEnum storeControllerType;

        [Tooltip("Send event when a controller is disconnected.")]
        public FsmEvent sendEvent;

        private bool hasEvent = false;

        public override void Awake() {
            base.Awake();
            ReInput.ControllerDisconnectedEvent += OnControllerDisconnected;
        }

        public override void Reset() {
            base.Reset();
            storeControllerName = string.Empty;
            storeControllerId = -1;
            storeControllerType = null;
            hasEvent = false;
        }

        protected override void DoUpdate() {
            if(hasEvent) {
                if(!FsmEvent.IsNullOrEmpty(sendEvent)) Fsm.Event(sendEvent);
                hasEvent = false;
            }
        }

        private void OnControllerDisconnected(ControllerStatusChangedEventArgs args) {
            hasEvent = true;
            storeControllerName.Value = args.name;
            storeControllerId.Value = args.controllerId;
            storeControllerType.Value = args.controllerType;
        }
    }

    #endregion
}
