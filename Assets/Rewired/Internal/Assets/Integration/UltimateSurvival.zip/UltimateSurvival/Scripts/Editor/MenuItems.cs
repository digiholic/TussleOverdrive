﻿// Copyright (c) 2017 Augie R. Maddox, Guavaman Enterprises. All rights reserved.
#pragma warning disable 0219
#pragma warning disable 0618
#pragma warning disable 0649

namespace Rewired.Integration.UltimateSurvival.Editor {
    using UnityEngine;
    using UnityEditor;
    using System;
    using System.Collections.Generic;

    public class MenuItems {

        private const string menuRoot = Consts.menuRoot + "/Integration";
        private const string packageName = "Ultimate Survival";
        private const string assetGuid_rewiredInputManager = "e160187a8b9808947a70bce73a4780ee";

        [MenuItem(menuRoot + "/" + packageName + "/Create/Rewired Input Manager")]
        [MenuItem("GameObject/Create Other/Rewired/Integration/" + packageName + "/Rewired Input Manager")]
        public static void CreateInputManager() {
            if(!InstantiatePrefabAtGuid(assetGuid_rewiredInputManager, "Rewired " + packageName + " Input Manager", true)) {
                Debug.LogError("Unable to locate prefab file. Please reinstall the " + packageName + " integration pack.");
            }
        }

        private static bool InstantiatePrefabAtGuid(string guid, string name, bool breakPrefabInstance) {
            GameObject prefab = LoadAssetAtGuid<GameObject>(guid);
            if(prefab == null) return false;

            GameObject instance = GameObject.Instantiate(prefab);
            if(instance == null) return false;

            if(!string.IsNullOrEmpty(name)) {
                instance.name = name;
            } else {
                // Strip (Clone) off the end of the name
                if(instance.name.EndsWith("(Clone)")) {
                    instance.name = instance.name.Substring(0, instance.name.Length - 7);
                }
            }

            if(breakPrefabInstance) PrefabUtility.DisconnectPrefabInstance(instance);
            Undo.RegisterCreatedObjectUndo(instance, "Create " + prefab.name);
            return true;
        }

        private static T LoadAssetAtGuid<T>(string guid) where T : UnityEngine.Object {
            return AssetDatabase.LoadAssetAtPath<T>(AssetDatabase.GUIDToAssetPath(guid));
        }
    }
}